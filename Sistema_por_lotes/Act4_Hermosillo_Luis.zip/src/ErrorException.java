public class ErrorException extends Exception{
    public ErrorException(){

    }
}
