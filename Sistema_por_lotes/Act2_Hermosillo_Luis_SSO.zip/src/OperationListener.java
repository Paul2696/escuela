import java.util.List;

public interface OperationListener {
    void operationDone(Operation operation);
    void batchDone();
    void operationRunning(Operation operation, int seconds);
    void updateBatchList(List<Operation> operations);
}
